﻿using UnityEngine;
using System.Collections;

public class Projectile : MonoBehaviour {
    public bool move = false;
    public Vector2 target;
    public float speed;
	// Use this for initialization
	void Start () {
        
	}
	
	// Update is called once per frame
	void Update () {
        if (move) {
            this.transform.position = Vector2.MoveTowards(this.transform.position, target, speed*Time.deltaTime);
         }
        
	}
}
