using System;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace UnityStandardAssets._2D
{
    public class Restarter : MonoBehaviour
    {
        private void OnCollisioTrigger2D(Collider2D other)
        {   Debug.Log("deleted");
            if (other.tag == "Player")
            {
                SceneManager.LoadScene(SceneManager.GetSceneAt(0).path);
            }
            else if (other.gameObject.transform.parent)
            {
                Debug.Log("DESTROYED " + other.gameObject.transform.parent);
                Destroy (other.gameObject.transform.parent.gameObject);
            }
            else
            {
                Destroy (other.gameObject);
                Debug.Log("Nadestroy ang else");
            }            
        }
    }
}
