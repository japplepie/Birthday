using System;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace UnityStandardAssets._2D
{
    public class Restarter : MonoBehaviour
    {
        void Update(){
            //Debug.Log(this.transform.position);
            //Debug.Log(this.name);
        }
        private void OnTriggerEnter2D(Collider2D other)
        {   Debug.Log("deleted");
            if (other.tag == "Player")
            {
                SceneManager.LoadScene(SceneManager.GetSceneAt(0).path);
            }
            else if (other.gameObject.transform.parent)
            {
                Destroy (other.gameObject.transform.parent.gameObject);
            }
            else
            {
                Destroy (other.gameObject);
            }            
        }
    }
}
