using System;
using UnityEngine;
using UnityStandardAssets.CrossPlatformInput;
//add fall time, if fall time > longtime -> earth die respawn platforms
namespace UnityStandardAssets._2D
{
    [RequireComponent(typeof (PlatformerCharacter2D))]
    public class Platformer2DUserControl : MonoBehaviour
    {   public float speed = 1.5f;
        private PlatformerCharacter2D m_Character;
        private bool m_Jump;
        private BoxCollider2D myCollider1;
        private CircleCollider2D myCollider2;

        private void cosmicQuack(){
            GameObject tempe =  Instantiate(GameObject.Find("Quack"), this.transform.position, Quaternion.identity) as GameObject;
            Projectile s = tempe.GetComponent("Projectile") as Projectile;
            s.move = true;
            Vector2 tempTarget = Camera.main.ScreenToWorldPoint(Input.mousePosition); //temp
            tempTarget.x *= 1000f;                                                    //temp
            tempTarget.y *= 1000f;                                                    //temp
            s.target = tempTarget;                                                    //temp
        }                                                                             

        private void tunnelling(){//9 normal player, 10 tunnelled player
            gameObject.layer = (gameObject.layer==9)?(gameObject.layer=10):(gameObject.layer=9);
            Debug.Log(gameObject.layer);
        }
        
        private void Awake()
        {
            m_Character = GetComponent<PlatformerCharacter2D>();
            myCollider1 = GetComponent<BoxCollider2D>();
           myCollider2 = GetComponent<CircleCollider2D>();
        }

        private void Update()
        {

        }


        private void FixedUpdate()
        {
            // Read the inputs.
            bool tunnel = CrossPlatformInputManager.GetButtonDown("Fire1");
            bool m_Jump = CrossPlatformInputManager.GetButtonDown("Jump");
            float h = CrossPlatformInputManager.GetAxis("Horizontal");
            // Pass all parameters to the character control script.
            // m_Character.Move(h, crouch, m_Jump);
            m_Character.Move(speed*h, false, m_Jump);
            
            if(Input.GetMouseButtonDown(0)){
                cosmicQuack();
            }
            
            if(tunnel)
            {
                tunnelling();
            }
            
        }
    }
}
