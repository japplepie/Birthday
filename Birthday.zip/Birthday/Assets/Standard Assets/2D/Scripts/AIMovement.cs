﻿using UnityEngine;
using System.Collections;
//add despawn time
public class AIMovement : MonoBehaviour {
    private Rigidbody2D enemyBody;
    private GameObject player;
    public float enemySpeed;
    public bool move = false;
	// Use this for initialization
	void Start () {
        enemyBody = GetComponent<Rigidbody2D>();
        player = GameObject.Find("CharacterRobotBoy");
	}
    
	// Update is called once per frame
	void Update () {
        if (move)
            this.transform.position = Vector2.MoveTowards(this.transform.position, player.transform.position, enemySpeed*Time.deltaTime);
	}
}
