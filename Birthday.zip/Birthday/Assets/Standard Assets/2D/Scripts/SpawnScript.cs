﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


public class SpawnScript : MonoBehaviour {
    // Use this for initialization
    private Vector2 originPosition;
    public static Queue platforms;
    private float posY;
    void Start()
    {
        originPosition = transform.position;
        platforms = new Queue();
        
    }
    private void OnTriggerEnter2D(Collider2D other)
    {   if (other.tag == "Player")
        {

            for(int i = 1; i <= 5; i++)
            {
                GameObject temp = Instantiate(GameObject.Find("Platform02"), new Vector2(Random.Range(0, 10),  posY + 10), Quaternion.identity) as GameObject;
                platforms.Enqueue(temp);
                if (platforms.Count > 1+5)
                {
                    Destroy(platforms.Dequeue() as GameObject);
                }
                posY = posY + 10;
            }
            this.transform.position = originPosition + new Vector2(0, (10 * 5));
            originPosition = this.transform.position;
        }
	}
}
