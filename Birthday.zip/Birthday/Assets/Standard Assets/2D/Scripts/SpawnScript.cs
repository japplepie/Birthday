﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

//offset hanggang di makita new spawning platforms
public class SpawnScript : MonoBehaviour {
    // Use this for initialization
    private Vector2 originPosition;
    public static Queue platforms;
    private float posY;
    private float dy = 9;
    private float dx = 36;
    private int spawns = 5;
    void Start()
    {
        originPosition = transform.position;
        platforms = new Queue();
        for(int i = 1; i <= spawns; i++)
        {
            GameObject temp = Instantiate(GameObject.Find("Platform02"), new Vector2(Random.Range(0, dx)-dx/2,  posY+dy), Quaternion.identity) as GameObject;
            platforms.Enqueue(temp);
            posY = posY + dy;
        }
    }
    private void OnTriggerEnter2D(Collider2D other)
    {   if (other.tag == "Player")
        {
            for(int i = 1; i <= spawns; i++)
            {
                GameObject temp = Instantiate(GameObject.Find("Platform02"), new Vector2(Random.Range(0, dx)-dx/2,  posY + dy), Quaternion.identity) as GameObject;
                platforms.Enqueue(temp);
                if (platforms.Count > 2*spawns)
                {
                    Destroy(platforms.Dequeue() as GameObject);
                }
                posY = posY + dy;
            }
            GameObject tempe =  Instantiate(GameObject.Find("Enemy"), new Vector2(Random.Range(0, dx)-dx/2, originPosition.y-spawns*dy),
            Quaternion.identity) as GameObject;
            AIMovement s = tempe.GetComponent("AIMovement") as AIMovement;
            s.move = true;
            this.transform.position = originPosition + new Vector2(0, (dy * spawns));
            originPosition = this.transform.position;
        }
	}
}
