﻿using UnityEngine;
using System.Collections;

public class SpawnScript : MonoBehaviour {
	// Use this for initialization
	private void OnTriggerEnter2D(Collider2D other)
    {   if (other.tag == "Player")
        {
            Instantiate(GameObject.Find("Platform02"), this.transform.position, Quaternion.identity);
        }
	}
}
